$('#example').DataTable({
    data: {{ dataT | safe }}
                        });